# -*- coding: utf-8 -*-
with open('app_kiem_diem_chi_bo_2.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos_save = text.find('function saveSelfEvaluation(')
print(text[pos_save:pos_save+2000])
