# -*- coding: utf-8 -*-
with open('app_kiem_diem_chi_bo_2.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos_load = text.find('function loadEvaluationForm(')
print(text[pos_load+5500:pos_load+7500])
