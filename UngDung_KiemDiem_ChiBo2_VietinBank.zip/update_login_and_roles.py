# -*- coding: utf-8 -*-
import json
import re

with open('app_kiem_diem_chi_bo_2.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Add username and password fields to DEFAULT_MEMBERS in JavaScript
old_default_members = """    const DEFAULT_MEMBERS = [
      { id: 1, name: "BÙI KHẮC DUY", phone: "0912345601", status: "Chính thức", role_party: "Đảng viên", title_pro: "Cán bộ", dept: "Chi nhánh Bảo Lộc", pin: "681234", present: true, self_score: 95, self_ranking: "Hoàn thành tốt nhiệm vụ", self_good: "Lập trường tư tưởng vững vàng, chấp hành tốt nội quy ngân hàng và quy chế Đảng.", self_limit: "Cần tích cực phát biểu xây dựng chi bộ hơn trong các buổi sinh hoạt.", self_sol: "Nâng cao năng lực chuyên môn và tinh thần tự phê bình và phê bình.", receptive_note: "Nghiêm túc tiếp thu toàn bộ ý kiến đóng góp của các đồng chí.", host_conclusion: "Đồng chí hoàn thành tốt nhiệm vụ được giao." },"""

new_default_members = """    const DEFAULT_MEMBERS = [
      { id: 1, name: "BÙI KHẮC DUY", username: "buikhacduy", password: "123456", phone: "0912345601", status: "Chính thức", role_party: "Đảng viên", title_pro: "Cán bộ", dept: "Chi nhánh Bảo Lộc", pin: "681234", present: true, self_score: 95, self_ranking: "Hoàn thành tốt nhiệm vụ", self_good: "Lập trường tư tưởng vững vàng, chấp hành tốt nội quy ngân hàng và quy chế Đảng.", self_limit: "Cần tích cực phát biểu xây dựng chi bộ hơn trong các buổi sinh hoạt.", self_sol: "Nâng cao năng lực chuyên môn và tinh thần tự phê bình và phê bình.", receptive_note: "Nghiêm túc tiếp thu toàn bộ ý kiến đóng góp của các đồng chí.", host_conclusion: "Đồng chí hoàn thành tốt nhiệm vụ được giao." },"""

if old_default_members in html:
    html = html.replace(old_default_members, new_default_members, 1)
    print("Updated DEFAULT_MEMBERS member 1 OK")

# Update all members in DEFAULT_MEMBERS to have username and password if missing
def add_user_credentials(match):
    s = match.group(0)
    # List of 12 names to usernames
    mapping = {
        'BÙI KHẮC DUY': 'buikhacduy',
        'VŨ HOÀNG NGUYÊN': 'vuhoangnguyen',
        'LÊ THANH NGHỊ': 'lethanhnghi',
        'HOÀNG THỊ THỦY': 'hoangthithuy',
        'NGUYỄN THỊ TỐ NGA': 'nguyenthitonga',
        'NGUYỄN THI THAO': 'nguyenthithao',
        'VÕ VĂN MẠNH': 'vovanmanh',
        'NGÔ THỊ KIM NGÂN': 'ngothikimngan',
        'NGUYỄN VĂN CHÂU': 'nguyenvanchau',
        'TRẦN ĐÌNH TIẾN DŨNG': 'trandinhtiendung',
        'ĐỖ THU HIỀN': 'dothuhien',
        'NGUYỄN DUY LỢI': 'nguyenduyloi'
    }
    for name, uname in mapping.items():
        if f'name: "{name}"' in s and 'username:' not in s:
            s = s.replace(f'name: "{name}",', f'name: "{name}", username: "{uname}", password: "123456",')
    return s

html = re.sub(r'const DEFAULT_MEMBERS = \[[\s\S]*?\];', add_user_credentials, html)
print("Updated all members in DEFAULT_MEMBERS with username & password OK")

# 2. Add Login Overlay right after <body>
old_body_start = '<body class="bg-vtb-grayBg text-slate-800 font-sans min-h-screen flex flex-col">'

login_overlay_html = """<body class="bg-vtb-grayBg text-slate-800 font-sans min-h-screen flex flex-col">

  <!-- ========================================== -->
  <!-- MÀN HÌNH ĐĂNG NHẬP BẢO MẬT DÀNH CHO 12 ĐẢNG VIÊN -->
  <!-- ========================================== -->
  <div id="login-overlay" class="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-gradient-to-br from-slate-950 via-vtb-navyDark to-slate-900 backdrop-blur-md overflow-y-auto">
    <div class="card-3d bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 sm:p-8 space-y-6 border border-slate-200 relative overflow-hidden">
      <!-- Header thẻ đăng nhập -->
      <div class="text-center space-y-2">
        <div class="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-vtb-navy to-vtb-red flex items-center justify-center shadow-lg border-2 border-vtb-gold/60">
          <span class="text-vtb-gold font-black text-2xl">★</span>
        </div>
        <div>
          <h4 class="text-[11px] font-black text-slate-500 uppercase tracking-wider">ĐẢNG BỘ VIETINBANK CHI NHÁNH BẢO LỘC</h4>
          <h2 class="text-xl font-black text-vtb-navy uppercase tracking-tight">CHI BỘ 2</h2>
          <p class="text-xs font-black text-vtb-red mt-0.5">KỲ KIỂM ĐIỂM & ĐÁNH GIÁ ĐẢNG VIÊN 2026</p>
        </div>
        <p class="text-[11px] text-slate-500 leading-relaxed pt-1">
          Hệ thống phân quyền độc lập: Mỗi đồng chí đăng nhập đúng tài khoản để tự chấm điểm, nhận xét chéo và bỏ phiếu kín theo quyền hạn.
        </p>
      </div>

      <!-- Form đăng nhập -->
      <form id="login-form" onsubmit="handleLoginSubmit(event)" class="space-y-4">
        <div>
          <label class="block text-xs font-bold text-slate-700 uppercase mb-1">
            <i class="fa-solid fa-user text-vtb-navy mr-1"></i> Tên đăng nhập:
          </label>
          <input type="text" id="login-username" required autocomplete="username"
            placeholder="vd: nguyenthithao, buikhacduy..."
            class="w-full text-xs font-bold p-3 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-vtb-navy focus:border-vtb-navy transition lowercase">
          <p class="text-[10px] text-slate-400 mt-1 italic">* Tên đảng viên viết liền, không dấu, chữ thường (vd: Nguyễn Thi Thao ➔ nguyenthithao)</p>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-700 uppercase mb-1">
            <i class="fa-solid fa-key text-vtb-navy mr-1"></i> Mật khẩu:
          </label>
          <div class="relative">
            <input type="password" id="login-password" required autocomplete="current-password"
              value="123456" placeholder="Mặc định: 123456"
              class="w-full text-xs font-bold p-3 border border-slate-300 rounded-xl bg-slate-50 focus:bg-white focus:ring-2 focus:ring-vtb-navy focus:border-vtb-navy transition pr-10">
            <button type="button" onclick="togglePasswordVisibility()" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
              <i id="pwd-toggle-icon" class="fa-solid fa-eye text-xs"></i>
            </button>
          </div>
          <p class="text-[10px] text-slate-400 mt-1 italic">* Mật khẩu khởi tạo chung cho toàn thể đảng viên là: <strong>123456</strong></p>
        </div>

        <div id="login-error" class="hidden p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2">
          <i class="fa-solid fa-triangle-exclamation text-rose-600"></i>
          <span id="login-error-msg">Tên đăng nhập hoặc mật khẩu không chính xác!</span>
        </div>

        <button type="submit" id="btn-login-submit" class="btn-3d w-full bg-gradient-to-r from-vtb-navy via-vtb-navyDark to-vtb-navy hover:from-vtb-red hover:to-vtb-redDark text-white py-3 rounded-xl font-black text-xs uppercase tracking-wider shadow-xl transition flex items-center justify-center gap-2">
          <i class="fa-solid fa-right-to-bracket text-amber-300"></i>
          <span>Đăng Nhập Vào Hệ Thống</span>
        </button>
      </form>

      <!-- Nút mở bảng tra cứu danh sách tên đăng nhập -->
      <div class="border-t border-slate-200 pt-3 text-center">
        <button type="button" onclick="toggleUsernameHelper()" class="text-xs font-bold text-vtb-navy hover:text-vtb-red transition flex items-center justify-center gap-1.5 mx-auto">
          <i class="fa-solid fa-circle-question text-amber-500"></i>
          <span>Bấm để tra cứu Tên đăng nhập của 12 đồng chí</span>
        </button>

        <!-- Danh sách tra cứu sổ tay tài khoản -->
        <div id="username-helper-box" class="hidden mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-left text-xs max-h-52 overflow-y-auto custom-scrollbar space-y-1.5">
          <p class="font-bold text-slate-700 pb-1 border-b text-[11px]">Bấm vào tên để tự động điền tài khoản & mật khẩu:</p>
          <div id="quick-login-list" class="grid grid-cols-1 gap-1">
            <!-- Populated dynamically -->
          </div>
        </div>
      </div>
    </div>
  </div>"""

if old_body_start in html:
    html = html.replace(old_body_start, login_overlay_html, 1)
    print("Added Login Overlay OK")
else:
    print("Error: old_body_start not found")

# 3. Replace Header User Role Selector with Fixed Session User Profile & Logout button
old_header_controls = """      <!-- User Role Selector & Fast Actions 3D -->
      <div class="flex items-center flex-wrap gap-2.5">
        <div
          class="bg-slate-900/60 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/20 flex items-center gap-2.5 shadow-inner">
          <label class="text-xs text-blue-200 font-bold flex items-center gap-1">
            <i class="fa-solid fa-user-check text-amber-300"></i> Vai trò:
          </label>
          <select id="current-user-select" onchange="switchUserRole(this.value)"
            class="bg-vtb-navyDark text-white text-xs font-bold px-2.5 py-1 rounded-lg border border-vtb-gold/60 focus:outline-none focus:ring-2 focus:ring-vtb-gold shadow">
            <!-- Dynamic Options -->
          </select>
          <span id="header-user-badge"
            class="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-extrabold bg-amber-400 text-slate-950 shadow-sm">
            <i class="fa-solid fa-shield-halved"></i>
            <span id="header-user-role-label">Bí thư Chi bộ</span>
          </span>
        </div>"""

new_header_controls = """      <!-- User Session Profile & Controls -->
      <div class="flex items-center flex-wrap gap-2.5">
        <div id="session-user-box"
          class="bg-slate-900/70 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-white/20 flex items-center gap-3 shadow-inner">
          <div class="w-8 h-8 rounded-lg bg-vtb-gold/20 text-vtb-gold flex items-center justify-center font-bold text-xs border border-vtb-gold/40 shadow-sm">
            <i class="fa-solid fa-user-tie"></i>
          </div>
          <div>
            <div class="flex items-center gap-1.5">
              <span id="session-user-name" class="text-xs font-black text-white tracking-wide">NGUYỄN THI THAO</span>
              <span id="session-user-badge" class="px-2 py-0.5 rounded text-[10px] font-black bg-amber-400 text-slate-950 shadow-sm">Bí thư</span>
            </div>
            <div id="session-user-detail" class="text-[10px] text-blue-200 font-medium">Bí thư Chi bộ - Phó Giám đốc CN</div>
          </div>
          <button type="button" onclick="handleLogout()"
            class="ml-1 text-[11px] text-rose-200 hover:text-white bg-rose-950/70 hover:bg-rose-700 px-2.5 py-1 rounded-lg border border-rose-500/30 transition flex items-center gap-1 font-bold shadow-sm" title="Đăng xuất khỏi thiết bị này">
            <i class="fa-solid fa-right-from-bracket"></i>
            <span class="hidden sm:inline">Đăng xuất</span>
          </button>
        </div>"""

if old_header_controls in html:
    html = html.replace(old_header_controls, new_header_controls, 1)
    print("Replaced Header Controls with Session User Profile OK")
else:
    print("Warning: old_header_controls not found")

# 4. In Tab 2: Wrap management tools in #member-management-tools
old_tab2_tools = """            <!-- Nút Tải Mẫu Excel -->
            <button onclick="downloadTemplateExcel()"
              class="text-xs bg-slate-700 hover:bg-slate-800 text-white px-3 py-1.5 rounded-lg font-bold flex items-center gap-1 transition shadow">"""

new_tab2_tools = """            <div id="member-management-tools" class="flex items-center flex-wrap gap-2">
            <!-- Nút Tải Mẫu Excel -->
            <button onclick="downloadTemplateExcel()"
              class="text-xs bg-slate-700 hover:bg-slate-800 text-white px-3 py-1.5 rounded-lg font-bold flex items-center gap-1 transition shadow">"""

if old_tab2_tools in html:
    html = html.replace(old_tab2_tools, new_tab2_tools, 1)
    # Close div after copyMemberPINList button
    old_pin_btn = """            <!-- Nút Sao Chép Mã PIN -->
            <button onclick="copyMemberPINList()"
              class="text-xs bg-purple-600 hover:bg-purple-700 text-white px-3 py-1.5 rounded-lg font-bold flex items-center gap-1 transition shadow">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
              </svg>
              Xuất Mã PIN Gửi Zalo
            </button>
          </div>
        </div>"""
    new_pin_btn = """            <!-- Nút Sao Chép Mã PIN -->
            <button onclick="copyMemberPINList()"
              class="text-xs bg-purple-600 hover:bg-purple-700 text-white px-3 py-1.5 rounded-lg font-bold flex items-center gap-1 transition shadow">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
              </svg>
              Xuất Mã PIN Gửi Zalo
            </button>
            </div>
          </div>
        </div>"""
    html = html.replace(old_pin_btn, new_pin_btn, 1)
    print("Wrapped Tab 2 member tools in #member-management-tools OK")
else:
    print("Warning: old_tab2_tools not found")

# 5. In Tab 4: Replace reviewer switch dropdown with fixed Current Reviewer badge
old_tab4_reviewer_switch = """          <div class="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg shadow-sm">
            <label class="text-xs font-bold text-slate-700 whitespace-nowrap">Đổi người nhận xét:</label>
            <select id="tab4-reviewer-select" onchange="switchUserRole(this.value)"
              class="text-xs font-bold bg-white border border-slate-300 rounded-md px-2 py-1 text-vtb-navy focus:ring-1 focus:ring-vtb-navy">
              <!-- populated in renderUserSelector -->
            </select>
          </div>"""

new_tab4_reviewer_switch = """          <div class="flex items-center gap-2 bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-lg shadow-sm">
            <span class="text-xs font-bold text-slate-600">Người nhận xét:</span>
            <span id="tab4-current-reviewer-badge" class="text-xs font-black text-vtb-navy flex items-center gap-1.5">
              <i class="fa-solid fa-user-check text-emerald-600"></i>
              <span id="current-reviewer-display">NGUYỄN THI THAO</span>
            </span>
          </div>"""

if old_tab4_reviewer_switch in html:
    html = html.replace(old_tab4_reviewer_switch, new_tab4_reviewer_switch, 1)
    print("Replaced Tab 4 Reviewer Switch with Fixed Badge OK")
else:
    print("Warning: old_tab4_reviewer_switch not found")

# 6. Add Login & Authentication JavaScript
old_render_user_selector = """    // USER SELECTOR VÀ PHÂN QUYỀN VAI TRÒ
    function renderUserSelector() {"""

new_login_auth_js = """    // ==========================================
    // HỆ THỐNG ĐĂNG NHẬP & PHÂN QUYỀN CHỨC NĂNG TỪNG ĐẢNG VIÊN
    // ==========================================
    function toUsernameSlug(name) {
      if (!name) return '';
      return name.normalize('NFD')
        .replace(/[\\u0300-\\u036f]/g, '')
        .replace(/đ/g, 'd').replace(/Đ/g, 'D')
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '');
    }

    function checkUserSession() {
      try {
        const sessionStr = localStorage.getItem('chibo2_session_user');
        if (sessionStr) {
          const u = JSON.parse(sessionStr);
          if (u && u.id && appData.members.some(m => m.id === u.id)) {
            appData.current_user_id = u.id;
            hideLoginOverlay();
            applyRolePermissions();
            return true;
          }
        }
      } catch (e) {
        console.error('Session parse error:', e);
      }
      showLoginOverlay();
      return false;
    }

    function showLoginOverlay() {
      const overlay = document.getElementById('login-overlay');
      if (overlay) overlay.classList.remove('hidden');
      renderQuickLoginHelper();
    }

    function hideLoginOverlay() {
      const overlay = document.getElementById('login-overlay');
      if (overlay) overlay.classList.add('hidden');
    }

    function togglePasswordVisibility() {
      const pwdInp = document.getElementById('login-password');
      const icon = document.getElementById('pwd-toggle-icon');
      if (!pwdInp) return;
      if (pwdInp.type === 'password') {
        pwdInp.type = 'text';
        if (icon) icon.className = 'fa-solid fa-eye-slash text-xs';
      } else {
        pwdInp.type = 'password';
        if (icon) icon.className = 'fa-solid fa-eye text-xs';
      }
    }

    function toggleUsernameHelper() {
      const box = document.getElementById('username-helper-box');
      if (box) box.classList.toggle('hidden');
    }

    function renderQuickLoginHelper() {
      const container = document.getElementById('quick-login-list');
      if (!container) return;
      container.innerHTML = '';

      appData.members.forEach(m => {
        const u = m.username || toUsernameSlug(m.name);
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'w-full text-left p-1.5 rounded hover:bg-blue-100 flex items-center justify-between transition text-[11px]';
        btn.innerHTML = `
          <span><strong class="text-slate-800">${m.name}</strong> <span class="text-slate-500 text-[10px]">(${m.role_party})</span></span>
          <span class="font-mono text-vtb-navy font-bold bg-white px-1.5 py-0.5 rounded border border-slate-200">${u}</span>
        `;
        btn.onclick = () => {
          document.getElementById('login-username').value = u;
          document.getElementById('login-password').value = '123456';
          const err = document.getElementById('login-error');
          if (err) err.classList.add('hidden');
          document.getElementById('btn-login-submit').focus();
        };
        container.appendChild(btn);
      });
    }

    function handleLoginSubmit(e) {
      e.preventDefault();
      const uInp = document.getElementById('login-username');
      const pInp = document.getElementById('login-password');
      const username = (uInp ? uInp.value : '').toLowerCase().trim();
      const password = (pInp ? pInp.value : '').trim();
      const errorBox = document.getElementById('login-error');
      const errorMsg = document.getElementById('login-error-msg');

      if (errorBox) errorBox.classList.add('hidden');

      // 1. Thử gọi API backend server
      fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      })
      .then(res => res.json().then(data => ({ status: res.status, data })))
      .then(result => {
        if (result.status === 200 && result.data.status === 'success') {
          const member = result.data.member;
          completeLogin(member);
        } else {
          showLoginError(result.data.message || 'Tên đăng nhập hoặc mật khẩu không chính xác!');
        }
      })
      .catch(err => {
        // Fallback kiểm tra cục bộ cho chế độ file:///
        const mem = appData.members.find(m => {
          const u = m.username || toUsernameSlug(m.name);
          return u === username;
        });

        if (!mem) {
          showLoginError(`Không tìm thấy tên đăng nhập "${username}". Vui lòng viết liền không dấu (vd: nguyenthithao, buikhacduy...)`);
          return;
        }

        const expectedPwd = mem.password || '123456';
        if (password !== expectedPwd && password !== '123456') {
          showLoginError('Mật khẩu không chính xác. Mật khẩu khởi tạo chung là 123456!');
          return;
        }

        completeLogin(mem);
      });
    }

    function showLoginError(msg) {
      const errorBox = document.getElementById('login-error');
      const errorMsg = document.getElementById('login-error-msg');
      if (errorMsg) errorMsg.textContent = msg;
      if (errorBox) errorBox.classList.remove('hidden');
    }

    function completeLogin(member) {
      appData.current_user_id = member.id;
      try {
        localStorage.setItem('chibo2_session_user', JSON.stringify(member));
      } catch (e) {}

      hideLoginOverlay();
      applyRolePermissions();
      renderAll();
      showToast(`Đăng nhập thành công! Chào đồng chí ${member.name}`, 'success');
    }

    function handleLogout() {
      if (confirm('Đồng chí có chắc chắn muốn đăng xuất khỏi phiên làm việc này không?')) {
        try {
          localStorage.removeItem('chibo2_session_user');
        } catch (e) {}
        showLoginOverlay();
        const uInp = document.getElementById('login-username');
        if (uInp) uInp.value = '';
        showToast('Đã đăng xuất thành công!', 'info');
      }
    }

    // Áp dụng phân quyền chặt chẽ cho từng chức danh
    function applyRolePermissions() {
      const cur = appData.members.find(m => m.id === appData.current_user_id) || appData.members[0];
      const isLeader = (cur.role_party === 'Bí thư Chi bộ' || cur.role_party === 'Phó Bí thư Chi bộ');

      // Cập nhật Header Profile
      const nameElem = document.getElementById('session-user-name');
      if (nameElem) nameElem.textContent = cur.name;
      const badgeElem = document.getElementById('session-user-badge');
      if (badgeElem) {
        if (cur.role_party === 'Bí thư Chi bộ') {
          badgeElem.textContent = '👑 Bí thư';
          badgeElem.className = 'px-2 py-0.5 rounded text-[10px] font-black bg-amber-400 text-slate-950 shadow-sm';
        } else if (cur.role_party === 'Phó Bí thư Chi bộ' || cur.role_party === 'Chi ủy viên') {
          badgeElem.textContent = '⭐ ' + cur.role_party;
          badgeElem.className = 'px-2 py-0.5 rounded text-[10px] font-black bg-blue-300 text-slate-950 shadow-sm';
        } else if (cur.status === 'Dự bị') {
          badgeElem.textContent = '⏳ Đảng viên dự bị';
          badgeElem.className = 'px-2 py-0.5 rounded text-[10px] font-black bg-slate-300 text-slate-800 shadow-sm';
        } else {
          badgeElem.textContent = '👤 Đảng viên';
          badgeElem.className = 'px-2 py-0.5 rounded text-[10px] font-black bg-emerald-400 text-slate-950 shadow-sm';
        }
      }
      const detailElem = document.getElementById('session-user-detail');
      if (detailElem) detailElem.textContent = `${cur.role_party} • ${cur.title_pro || 'Cán bộ'} - ${cur.dept || 'Chi nhánh Bảo Lộc'}`;

      // Tab 2: Quản lý danh sách đảng viên (Chỉ Bí thư được thêm, sửa, import)
      const memberTools = document.getElementById('member-management-tools');
      if (memberTools) {
        if (isLeader) memberTools.classList.remove('hidden');
        else memberTools.classList.add('hidden');
      }

      // Tab 4: Điều phối phân công nhận xét (Chỉ Bí thư được phân công)
      const leaderAssignTools = document.getElementById('leader-assign-tools');
      if (leaderAssignTools) {
        if (isLeader) leaderAssignTools.classList.remove('hidden');
        else leaderAssignTools.classList.add('hidden');
      }

      const curRevDisp = document.getElementById('current-reviewer-display');
      if (curRevDisp) curRevDisp.textContent = `${cur.name} (${cur.role_party})`;
    }

    // USER SELECTOR VÀ PHÂN QUYỀN VAI TRÒ
    function renderUserSelector() {"""

if old_render_user_selector in html:
    html = html.replace(old_render_user_selector, new_login_auth_js, 1)
    print("Added Login & Auth JavaScript OK")
else:
    print("Warning: old_render_user_selector not found")

# 7. Update renderEvaluationTargetSelect to filter based on logged-in user
old_render_eval_target = """    function renderEvaluationTargetSelect() {
      const sel = document.getElementById('eval-target-select');
      sel.innerHTML = '<option value="collective">⭐ TẬP THỂ CHI BỘ 2 (KHỐI DOANH NGHIỆP NHÀ NƯỚC)</option>';
      appData.members.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m.id;
        opt.textContent = `Đ/c ${m.name} - ${m.role_party} (${m.title_pro})`;
        sel.appendChild(opt);
      });
      loadEvaluationForm('collective');
    }"""

new_render_eval_target = """    function renderEvaluationTargetSelect() {
      const sel = document.getElementById('eval-target-select');
      if (!sel) return;
      sel.innerHTML = '';

      const cur = appData.members.find(m => m.id === appData.current_user_id) || appData.members[0];
      const isLeader = (cur.role_party === 'Bí thư Chi bộ' || cur.role_party === 'Phó Bí thư Chi bộ');

      // Tùy chọn 1: Tập thể Chi bộ 2
      const optColl = document.createElement('option');
      optColl.value = 'collective';
      optColl.textContent = '⭐ TẬP THỂ CHI BỘ 2 (KHỐI DOANH NGHIỆP NHÀ NƯỚC)';
      sel.appendChild(optColl);

      if (isLeader) {
        // Bí thư / Cấp ủy: Xem và duyệt bản tự kiểm điểm của toàn bộ 12 đảng viên
        appData.members.forEach(m => {
          const opt = document.createElement('option');
          opt.value = m.id;
          opt.textContent = `Đ/c ${m.name} - ${m.role_party} (${m.title_pro})` + (m.id === cur.id ? ' [Bản của tôi]' : '');
          sel.appendChild(opt);
        });
        loadEvaluationForm('collective');
      } else {
        // Đảng viên thông thường: Chỉ tập trung tự chấm điểm bản của chính mình
        const optMe = document.createElement('option');
        optMe.value = cur.id;
        optMe.textContent = `⭐ Đ/c ${cur.name} (${cur.role_party}) - [BẢN TỰ KIỂM ĐIỂM CỦA TÔI]`;
        optMe.selected = true;
        sel.appendChild(optMe);
        loadEvaluationForm(String(cur.id));
      }
    }"""

if old_render_eval_target in html:
    html = html.replace(old_render_eval_target, new_render_eval_target, 1)
    print("Updated renderEvaluationTargetSelect with strict role restrictions OK")
else:
    print("Warning: old_render_eval_target not found")

# 8. Update DOMContentLoaded to trigger checkUserSession()
old_dom_ready = """    document.addEventListener('DOMContentLoaded', () => {
      loadStoredData();
      renderAll();
      setupProjectorSlides();
    });"""

new_dom_ready = """    document.addEventListener('DOMContentLoaded', () => {
      loadStoredData();
      // Khởi tạo tên đăng nhập cho từng đảng viên nếu chưa có
      appData.members.forEach(m => {
        if (!m.username) m.username = toUsernameSlug(m.name);
        if (!m.password) m.password = '123456';
      });
      checkUserSession();
      renderAll();
      setupProjectorSlides();
    });"""

if old_dom_ready in html:
    html = html.replace(old_dom_ready, new_dom_ready, 1)
    print("Updated DOMContentLoaded to checkUserSession OK")
else:
    print("Warning: old_dom_ready not found")

with open('app_kiem_diem_chi_bo_2.html', 'w', encoding='utf-8') as f:
    f.write(html)

print("Saved app_kiem_diem_chi_bo_2.html successfully! New length:", len(html))
