# -*- coding: utf-8 -*-
with open('app_kiem_diem_chi_bo_2.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('id="tab-self-evaluation"')
pos_end = text.find('</section>', pos)
print(text[pos+1000:pos_end])
