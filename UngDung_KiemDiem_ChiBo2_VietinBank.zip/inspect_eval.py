# -*- coding: utf-8 -*-
with open('app_kiem_diem_chi_bo_2.html', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.find('id="tab-self-evaluation"')
print("=== TAB 3 HTML ===")
print(text[pos:pos+1500])

print("\n=== loadEvaluationForm function ===")
pos_load = text.find('function loadEvaluationForm(')
print(text[pos_load:pos_load+1500])
